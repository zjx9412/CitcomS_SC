i=0
while (($i <= 5))
do
j=1
while (($j <= 12))
do
file=velbc_full$i.$j
mv $file ./changed/velbc_full$i.$(($j-1))
j=$(($j+1))
done
i=$(($i+1))
done
