#!/bin/bash
ModelName=practice1

root="/scratch/v05/jz1263/practice1"

timeFile="/scratch/v05/jz1263/practice1/practice1.timese"

#for TimeStep in $(awk '{print $1}' ${timeFile});  do  
for TimeStep in 0; do 
echo $TimeStep
for capNumber in 00 01; do

python3 OptToVtk.py ${root}/${ModelName}.cap${capNumber}.${TimeStep} /home/574/jz1263/job_script/pid000084712 

done
done
#print "Hadi Bakalim..."

echo "All Done! Good luck!"

# My default modules to run Models on Gadi are:

#1) pbs   3) intel-mkl/2019.3.199        5) python3/3.7.4   7) openmpi/4.0.2  
# 2) dot   4) intel-compiler/2019.3.199   6) gmt/4.5.18    
